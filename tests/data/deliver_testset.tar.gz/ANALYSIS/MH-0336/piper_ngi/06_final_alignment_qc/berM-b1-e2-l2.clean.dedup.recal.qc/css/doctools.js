./ANALYSIS/MH-0336/piper_ngi/06_final_alignment_qc/berM-b1-e2-l2.clean.dedup.recal.qc/css/doctools.js
